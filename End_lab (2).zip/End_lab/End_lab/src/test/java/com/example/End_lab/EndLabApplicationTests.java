package com.example.End_lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
